﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayComputer
{
    class Program
    {
        static void Main(string[] args)
        { int arraySize = 10;
            Computer [] computers = new Computer[arraySize ];
            //initilization;
            for (int i = 0; i < arraySize; i++)
            {
                Computer newcomputer = new Computer();
                computers[i] = newcomputer;
                computers[i].Color= "Blue" ;
                computers[i].Size = "Small";
            }
            //Print out the reuslt
            Console.WriteLine("Original results");
            #region Print results
            for (int i = 0; i < arraySize; i++)
            {
                Console.WriteLine("Computer {0} color= {1}", i, computers[i].Color);
            }
            for (int i = 0; i < arraySize; i++)
            {

                Console.WriteLine("Computer{0} size= {1}", i, computers[i].Size);
            }
            Console.WriteLine();
            #endregion


            // replicaComputers
            Computer[] replicaComputers = computers ;

            //change color in replica Computers
            for (int i = 0; i < arraySize/2; i++)
            {
                replicaComputers[arraySize - i-1].Color = "Red";
            }
            //print out the result 
            Console.WriteLine("Color is changed in replica computer array");
            #region Print out results
            for (int i = 0; i < arraySize; i++)
            {
                Console.WriteLine("Computer {0} color= {1}", i, computers[i].Color);
            }
            for (int i = 0; i < arraySize; i++)
            {

                Console.WriteLine("Computer{0} size= {1}", i, computers[i].Size);
            }
            Console.WriteLine();
            #endregion

            //Chage size in original arrays (computers)
            for (int i = 0; i < arraySize /2; i++)
            {
                 computers[i].Size = "Big";
            }
            Console.WriteLine("Size is changed in original computer array");
            for (int i = 0; i < arraySize; i++)
            {
                Console.WriteLine("Computer {0} color= {1}", i, computers[i].Color);
            }
            for (int i = 0; i < arraySize; i++)
            {

                Console.WriteLine("Computer{0} size= {1}", i, computers[i].Size);
            }
            Console.ReadLine();
        }
    }

    class Computer
    {   
        string color, size;
        #region Color
        public string Color
        {
            get
            { return color; }
            set
            {
                color = value;
            }
        }
        #endregion
        #region Size
        public string Size
        {
            get
            { return size; }
            set { this.size = value; }
        }
        #endregion

        
    }
}
