﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HWAbstractClass
{
    class Program
    {
        static void Main(string[] args)
        {
            double maxValue = 0;
            string color=" ",shape=" ";

            Shape triangle = new Triangle(2, 3, 4, "Blue" );
            Shape rectangle = new Rectangle(4, 3, "Green");
            Shape square = new Square(5, "Red");
           
            triangle.Display();
            rectangle.Display();
            square.Display();

           


            if (triangle.getArea() > rectangle.getArea())
            {
                if (triangle.getArea() > square.getArea())
                { maxValue = triangle.getArea();
                    color = triangle.Color;
                    shape = triangle.Name;
                }
                else
                {
                    maxValue = square.getArea();
                    color = square.Color;
                    shape = square.Name;
                }
            }
            else
            { if (rectangle.getArea()>square.getArea())
                { maxValue = rectangle.getArea();
                    color = rectangle.Color;
                    shape = rectangle.Name;
                }
                else
                {
                    maxValue = square.getArea();
                    color = square.Color;
                    shape = square.Name;
                }
            
            }
            Console.WriteLine("Max area= " + maxValue + "; Color =" + color + "; Shape =" + shape);
            if (triangle.getCircum() > rectangle.getCircum())
            {
                if (triangle.getCircum() > square.getCircum())
                {
                    maxValue = triangle.getCircum();
                    color = triangle.Color;
                    shape = triangle.Name;
                }
                else
                {
                    maxValue = square.getCircum();
                    color = square.Color;
                    shape = square.Name;
                }
            }
            else
            {
                if (rectangle.getCircum() > square.getCircum())
                {
                    maxValue = rectangle.getCircum();
                    color = rectangle.Color;
                    shape = rectangle.Name;
                }
                else
                {
                    maxValue = square.getCircum();
                    color = square.Color;
                    shape = square.Name;
                }

            }
            Console.WriteLine("Max circumstance = " + maxValue + "; Color =" + color + "; Shape =" + shape);

            Console.ReadLine();
        }

        abstract class Shape
        {
            
          
            public virtual string Name { get; set; }
            public virtual string Color
            { get; set; }

            public virtual double getArea()
            { double area = 0;
                return area; 
            }

            public virtual double getCircum()
            {
                double circum = 0;
                return circum;
            }
            public void Display()
            {
                Console.WriteLine(this.Name);
                Console.WriteLine("Area of "+this.Name+ "= {0:0.00}", this.getArea());
                Console.WriteLine("Circumstance of "+this.Name +"= {0:0.00}", this.getCircum ());
            }

        }
        class Triangle : Shape
        {
            string name="Triangle";
            double lengthA, lengthB, lengthC;
            string color;
            public override string Color
            { get {return color; }
                set { color = value; }
            }
            public override string  Name
            { get
                { return name; }
                set
                { }
            }
            public Triangle(double i, double j, double k, string color)
            {
                lengthA = i;
                lengthB = j;
                lengthC = k;
                this.color = color;
             }
            // calculate area
           
            public override double getArea()
            {
                double p = (lengthA + lengthB + lengthC) / 2;
                return Math.Sqrt(p * (p - lengthA) * (p - lengthB) * (p - lengthC));
                
            }
            //calculate circumstance
            public override double getCircum()
            {
                return lengthA +lengthB + lengthC ;
            }

            

        }
        class Rectangle:Shape
        {
            string name = "Reactangle";
            double width = 0, height = 0;
            string color;
            public override string Color
            {
                get { return color; }
                set { color = value; }
            }
            public override string Name
            {
                get
                { return name; }
                set
                { name = value; }
            }
            public Rectangle(double width, double height, string color)
            {
                this.width = width;
                this.height = height;
                this.color = color;
            }
            //calculate area
            public override double getArea()
            {
                return width*height;  
            }
            //calculate circumstance
            public override double getCircum()
            {
                return 2*width+2*height;
            }


        }
        class Square:Shape
        {
            string name = "Square";
            double width = 0;
            string color;
            public override string Color
            {
                get { return color; }
                set { color = value; }
            }
            public override string Name
            {
                get
                { return name; }
                set
                { }
            }
            public Square(double width, string color)
            {
                this.width = width;
                this.color = color;
            }

            //calculate area
            public override double getArea()
            {
                return width * width ;
            }
            //calculate circumstance
            public override double getCircum()
            {
                return 4 * width;
            }


        }
    }
}
