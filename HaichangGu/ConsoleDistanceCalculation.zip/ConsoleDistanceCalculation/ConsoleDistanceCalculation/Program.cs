﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDistanceCalculation
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 5;
            int b = 6;

            //==================================================================
            // Sum Operator
            int sum = Operator.Add(a, b);
            Console.WriteLine("The sum of a&b is: " + sum);


            // Sum Operator
            int multip = Operator.multiplication(a, b);
            Console.WriteLine("The multiplication of a&b is: " + multip);


            // Subtraction Operator
            int substraction = Operator.Subtraction(a, b);
            Console.WriteLine("The substration of a&b is: " + substraction);

            // Division Operator

            double division = Operator.Division(Convert.ToDouble ( a), Convert.ToDouble (b));
            Console.WriteLine("The division of a&b is: " + division);

            //===================================================================

            //********************************************************************

            //==================================================================
            // a + b + customized_number
            Operator Calucation_1 = new Operator();
            Calucation_1.CustomizeNum = 3;

            int threeNumberTotal = Calucation_1.Customize_1(a, b);
            Console.WriteLine("The sum of the three numnber is: " + threeNumberTotal);

            // (a + b) * customized number 


            //===================================================================

            //********************************************************************

            //==================================================================
            // (a + b + customized_number_A) + customized_number_B     
            Operator Calucation_2 = new Operator(5);
            Calucation_2.CustomizedNum_B = 3;

            int fourNumberTotal = Calucation_2.Customize_3(a, b);
            Console.WriteLine("The sum of the four numnber is: " + fourNumberTotal);
            Console.Read();

            /// (a + b - customized_number_A) * customized_number_B 


            //===================================================================


        }
    }

    class Operator
    {
       

        //===================================================================
        public static int Add(int A, int B)
        {
            int sum = A + B;
            return sum;
        }

        public static int multiplication(int A, int B)
        {
            int multip = A * B;
            return multip;
        }

        public static double Division(double  A, double  B)
        {
            double divisionResult=0;
            divisionResult = A / B;
            return divisionResult;
        }

        public static int Subtraction(int A, int B)
        {
            int subtractionResult = 0;
            subtractionResult = A - B;
            return subtractionResult;

        }
        //====================================================================

        public Operator()
        {

        }

        public int CustomizeNum { get; set; }

        public int Customize_1(int a, int b)
        {
            int customize_1 = a + b + CustomizeNum;
            return customize_1;
        }

        //public int Customize_2()
        //{

        //}
        //====================================================================
        int _customizedNum_A;

        public Operator(int customizeNum_A)
        {
            _customizedNum_A = customizeNum_A;
        }

        public int CustomizedNum_B { get; set; }

        public int Customize_3(int a, int b)
        {
            int customize_3 = (a + b + CustomizedNum_B) + _customizedNum_A;
            return customize_3;
        }


        //public int Customize_4()
        //{
            
        //}
    }
}
