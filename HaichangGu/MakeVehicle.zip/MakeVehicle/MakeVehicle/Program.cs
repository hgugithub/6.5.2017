﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MakeVehicle
{
    class Program
    {
        static void Main(string[] args)
        {
            string make = "Toyota", model = "Highlander";
            int year = 2016;
           
            // Using costructor to make a new vehicle with required information
            Vehicle vehicle = new Vehicle(make,year,model);
            Console.WriteLine(" Vehicle make: {0}\n Vehicle year: {1}\n Vehicle model: {2}\n", vehicle.Make, vehicle.Year, vehicle.Model );
            vehicle.Start ();
            vehicle.Accelerate(4, 4);
            vehicle.Accelerate(6, 3);
            vehicle.Speed();
            vehicle.Decelerate(-2, 4);
            vehicle.Speed();
            vehicle.Stop(3);
            vehicle.Speed();
            Console.ReadLine();
            
        }
    }

    class Vehicle
    {
        string make, model;
        int year;
        // propeties declaration
       public string Make
        { get
            {
                return make;
            }
                 set
            {
                make=value;
            }
        }
        public string Model
        {
            get
            {
                return model;
            }
            set
            {
                model=value;
            }
        }
        public int Year
        {
            get
            {
                return year;
            }
            set
            {
               year=value;

            }
        }
        // consructor
        public Vehicle(string make, int year, string model)
        {
            this.make=make;
            this.year = year;
            this.model = model;

        }
        // method 
        public double Speed()
        { Random random = new Random();
            double speed=0;
            speed = random.Next(0, 55);
            Console.WriteLine("Speed= {0} mile per hour", speed);
            return speed;

        }
        public void Accelerate(int accelerator, int time)
        {
            Console.WriteLine("Vehicle accelerates at {0} ft/s^2 in {1} seconds", accelerator, time);
            

        }
        public void Decelerate(int decelerator, int time)
        {
            Console.WriteLine("Vehicle Decelerates at {0} ft/s^2 in {1} seconds", decelerator, time);
        }

        public void Start()
        {
            Console.WriteLine("Start vehicle");
        }

        public void Stop(int time)
        {
            Console.WriteLine("Vehicle stops in {0} seconds", time);

        }

    }

}
